package com.unileste.formularioswing;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class FormularioSwing {
    public static void main(String[] args) {
        JFrame janela = new JFrame("Dados do usuario");
        janela.setLayout(new BorderLayout(10, 10));

        JPanel painelCampos = new JPanel(new GridLayout(4, 4, 10, 10));
        painelCampos.setBorder(BorderFactory.createTitledBorder("DADOS DO USUÁRIO"));

        JTextField campoNome = new JTextField();
        JTextField campoCpf = new JTextField();
        JTextField campoDtNasc = new JTextField();
        JTextField campoEmail = new JTextField();
        JTextField campoTelefone = new JTextField();
        JTextField campoEndereco = new JTextField();
        JTextField campoCargo = new JTextField();
        JComboBox<String> caixaStatus = new JComboBox<>(new String[]{"Ativo", "Inativo"});

        painelCampos.add(new JLabel("1. NOME COMPLETO:"));
        painelCampos.add(campoNome);
        painelCampos.add(new JLabel("5. TELEFONE:"));
        painelCampos.add(campoTelefone);

        painelCampos.add(new JLabel("2. CPF:"));
        painelCampos.add(campoCpf);
        painelCampos.add(new JLabel("6. ENDEREÇO:"));
        painelCampos.add(campoEndereco);

        painelCampos.add(new JLabel("3. DATA NASCIMENTO:"));
        painelCampos.add(campoDtNasc);
        painelCampos.add(new JLabel("7. CARGO:"));
        painelCampos.add(campoCargo);

        painelCampos.add(new JLabel("4. E-MAIL:"));
        painelCampos.add(campoEmail);
        painelCampos.add(new JLabel("8. STATUS:"));
        painelCampos.add(caixaStatus);

        JPanel painelBotoes = new JPanel(new GridLayout(1, 4, 10, 10));
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        painelBotoes.add(new JButton("Adicionar"));
        painelBotoes.add(new JButton("Atualizar"));
        painelBotoes.add(new JButton("Pesquisar"));
        painelBotoes.add(new JButton("Excluir"));

        janela.add(painelCampos, BorderLayout.CENTER);
        janela.add(painelBotoes, BorderLayout.SOUTH);

        janela.setSize(800, 300);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setLocationRelativeTo(null);
        janela.setVisible(true);
    }
}